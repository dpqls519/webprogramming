package com.yebean.app.controller;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class LessonForm {
    private Long id;
    private String name;
    private int quota;
}
